#ifndef UTIL_H
#define UTIL_H
#include <QString>
namespace util{
    QString getPasswordHash(QString pw);
}
#endif // UTIL_H
