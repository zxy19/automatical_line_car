#ifndef DATATYPE_H
#define DATATYPE_H

enum Type { BINARY, STRING, HTTP, CSV, MULTI_BYTE, UNKNOWN };

#endif