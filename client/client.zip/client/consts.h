#ifndef CONSTS_H
#define CONSTS_H
#include <QString>
extern QString PASSWORD_SALT;
#endif // CONSTS_H
