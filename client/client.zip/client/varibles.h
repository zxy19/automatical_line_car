#ifndef VARIBLES_H
#define VARIBLES_H
extern QString username;
#endif // VARIBLES_H
