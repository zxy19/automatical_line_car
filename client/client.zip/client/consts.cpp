#include "consts.h"

QString PASSWORD_SALT = "PASSWORD_FOR_SECURITY_&*(**H954y9h9fu";
